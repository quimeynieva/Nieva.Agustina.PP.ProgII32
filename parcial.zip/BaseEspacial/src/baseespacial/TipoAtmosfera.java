
package baseespacial;


public enum TipoAtmosfera {
    PRESURIZADA,
    VACIO
    }
          