
package baseespacial;


public class UnidadExistenteException extends Exception {
    public UnidadExistenteException() {
        super("Nombre de unidad ya existente");
    }

    public UnidadExistenteException(String mensaje) {
        super(mensaje);
    }
}
