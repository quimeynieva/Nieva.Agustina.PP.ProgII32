package baseespacial;

public class Main {
    public static void main(String[] args) {
        BaseEspacial base = new BaseEspacial();

        try {
            base.agregarUnidadOperativa(new Astronautas("Susan Storm", 1, TipoAtmosfera.PRESURIZADA, 5));
            base.agregarUnidadOperativa(new Robots("R2D2", 2, TipoAtmosfera.VACIO, 24));
            base.agregarUnidadOperativa(new Experimentos("Experimento 626", 3, TipoAtmosfera.PRESURIZADA, 10));
        } catch (UnidadExistenteException e) {
            System.out.println("Error al agregar: " + e.getMessage());
        }

        base.mostrarUnidades();
        base.moverUnidades();
        base.realizarFuncionesBase();
        base.filtrarPorTipoAtmosfera(TipoAtmosfera.PRESURIZADA);
    }
}
