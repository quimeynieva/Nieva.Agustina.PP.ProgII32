/*
*/
/*
*/
package baseespacial;




import java.util.ArrayList;

public class BaseEspacial {
    private ArrayList<UnidadesOperativas> unidades;

    public BaseEspacial() {
        unidades = new ArrayList<>();
    }

    public void agregarUnidadOperativa(UnidadesOperativas u) throws UnidadExistenteException {
        for (UnidadesOperativas existente : unidades) {
            if (existente.nombreIdentificador.equals(u.nombreIdentificador)
                    && existente.modulo == u.modulo) {
                throw new UnidadExistenteException();
            }
        }
        unidades.add(u);
    }

    public void mostrarUnidades() {
        for (UnidadesOperativas u : unidades) {
            System.out.println(u.getClass().getSimpleName() + " - " + u.nombreIdentificador +
                    " | Módulo: " + u.modulo + " | Atmósfera: " + u.tipoAtmosfera);
        }
    }

    public void moverUnidades() {
        for (UnidadesOperativas u : unidades) {
            if (u instanceof Experimentos) {
                System.out.println(u.nombreIdentificador + " no puede moverse (experimento fijo)");
            } else {
                System.out.println(u.nombreIdentificador + " se ha movido a otro módulo.");
            }
        }
    }

    public void realizarFuncionesBase() {
        for (UnidadesOperativas u : unidades) {
            u.reabastecerse();
            u.mantenerCondicionesAmosfericas();
            u.replicarse();
        }
    }

   public void filtrarPorTipoAtmosfera(TipoAtmosfera tipo) {
    for (UnidadesOperativas u : unidades) {
        if (u.tipoAtmosfera == tipo) {
            System.out.println(u.nombreIdentificador + " (" + tipo + ")");
        }
    }
}

        }
 


