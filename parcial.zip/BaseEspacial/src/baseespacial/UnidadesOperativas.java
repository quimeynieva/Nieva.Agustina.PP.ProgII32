
package baseespacial;

   abstract class UnidadesOperativas {
  
    protected String nombreIdentificador;
    protected int modulo;
    protected  TipoAtmosfera tipoAtmosfera;
   
    public UnidadesOperativas(
            String nombreIdentificador,
            int modulo,
             TipoAtmosfera tipoAtmosfera){
        this.nombreIdentificador=nombreIdentificador;
        this.modulo=modulo;
        this.tipoAtmosfera=tipoAtmosfera;
    }
    
    
    public void reabastecerse(){
        System.out.println("Reabasteciendo...");
    }
        public void mantenerCondicionesAmosfericas(){
        System.out.println("Haciendo mantenimiento de atmosfera...");
    }
    abstract void replicarse();
    
    
    abstract void cambiarModulo(int moduloNuevo);
    
}


class Astronautas extends UnidadesOperativas{
    private int maxEVA;/*horas*/
    public Astronautas( String nombreIdentificador,
     int modulo, TipoAtmosfera tipoAtmosfera,int maxEVA)
    {
    super( nombreIdentificador,
      modulo,tipoAtmosfera);
     this.maxEVA=maxEVA;
    }
    
  @Override
  public void replicarse(){
      System.out.println("Entrenando nuevos astronautas...");
  }
  public void cambiarModulo (int moduloNuevo){
      this.modulo=moduloNuevo;
  }
   
 
}



class Robots extends UnidadesOperativas{
    private int autonomiaOperativa;/*horas*/
    public Robots( String nombreIdentificador,
     int modulo, TipoAtmosfera tipoAtmosfera,int autonomiaOperativa)
    {
    super( nombreIdentificador,
      modulo,tipoAtmosfera);
     this.autonomiaOperativa=autonomiaOperativa;
    }

  @Override
  public void replicarse(){
      System.out.println("Copiando robots...");
  }
        public void cambiarModulo (int moduloNuevo){
      this.modulo=moduloNuevo;
  }
    
}

    class Experimentos extends UnidadesOperativas{
    private int duracionIdeal; /*dias*/
    public Experimentos( String nombreIdentificador,
     int modulo, TipoAtmosfera tipoAtmosfera, int duracionIdeal)
    {
    super( nombreIdentificador,
      modulo,tipoAtmosfera);
    this.duracionIdeal=duracionIdeal;
    }
    
  @Override
  public void replicarse(){
      System.out.println("Clonando protocolos...");
  }
    public void cambiarModulo (int moduloNuevo){
      System.out.println("esta unidad no puede moverse.");
  }
    
}


/*
*/