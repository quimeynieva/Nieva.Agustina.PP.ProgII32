package baseespacial;

public class UnidadExistenteException extends RuntimeException {
    public UnidadExistenteException() {
        super("Nombre de unidad ya existente en ese módulo");
    }

    public UnidadExistenteException(String mensaje) {
        super(mensaje);
    }
}
