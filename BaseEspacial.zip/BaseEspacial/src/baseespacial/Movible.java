package baseespacial;

public interface Movible {
    void cambiarModulo(int moduloNuevo);
}
