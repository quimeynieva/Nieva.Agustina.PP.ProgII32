package baseespacial;

import java.util.Objects;

public abstract class UnidadesOperativas {
    protected String nombreIdentificador;
    protected int modulo;
    protected TipoAtmosfera tipoAtmosfera;

    public UnidadesOperativas(String nombreIdentificador, int modulo, TipoAtmosfera tipoAtmosfera) {
        this.nombreIdentificador = nombreIdentificador;
        this.modulo = modulo;
        this.tipoAtmosfera = tipoAtmosfera;
    }

    
    public void reabastecerse() {
        System.out.println(nombreIdentificador + ": reabasteciéndose...");
    }

    public void mantenerCondicionesAtmosfericas() {
        System.out.println(nombreIdentificador + ": manteniendo condiciones atmosféricas...");
    }

    
    public boolean operaEn(TipoAtmosfera t) {
        return this.tipoAtmosfera == t;
    }

    
    public abstract void replicarse();
    public abstract void cambiarModulo(int moduloNuevo);

    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof UnidadesOperativas)) return false;
        UnidadesOperativas that = (UnidadesOperativas) o;
        return modulo == that.modulo &&
               Objects.equals(nombreIdentificador, that.nombreIdentificador);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombreIdentificador, modulo);
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() +
               " - " + nombreIdentificador +
               " | Módulo: " + modulo +
               " | Atmósfera: " + tipoAtmosfera;
    }
}
