package baseespacial;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        BaseEspacial base = new BaseEspacial();

        try {
            base.agregarUnidadOperativa(new Astronautas("Cmdr. Vega", 1, TipoAtmosfera.PRESURIZADA, 5));
            base.agregarUnidadOperativa(new Robots("R2-D2", 2, TipoAtmosfera.VACIO, 24));
            base.agregarUnidadOperativa(new Experimentos("Exp-1", 3, TipoAtmosfera.PRESURIZADA, 10));

            
            base.agregarUnidadOperativa(new Astronautas("Cmdr. Vega", 1, TipoAtmosfera.PRESURIZADA, 6));
        } catch (UnidadExistenteException e) {
            System.out.println("Excepción al agregar: " + e.getMessage());
        }

        System.out.println("\n--- Mostrar unidades ---");
        base.mostrarUnidades();

        System.out.println("\n--- Mover unidades ---");
        base.moverUnidades();

        System.out.println("\n--- Realizar funciones base ---");
        base.realizarFuncionesBase();

        System.out.println("\n--- Filtrar PRESURIZADA ---");
        List<UnidadesOperativas> pres = base.filtrarPorTipoAtmosfera(TipoAtmosfera.PRESURIZADA);
        for (UnidadesOperativas u : pres) {
            System.out.println(u);
        }
    }
}
