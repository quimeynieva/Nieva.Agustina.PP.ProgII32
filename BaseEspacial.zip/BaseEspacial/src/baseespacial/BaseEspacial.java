package baseespacial;

import java.util.ArrayList;
import java.util.List;

public class BaseEspacial {
    private ArrayList<UnidadesOperativas> unidades;

    public BaseEspacial() {
        unidades = new ArrayList<>();
    }

    
    public void agregarUnidadOperativa(UnidadesOperativas u) {
        if (unidades.contains(u)) {
            throw new UnidadExistenteException("Ya existe una unidad con ese nombre en el mismo módulo: " + u.nombreIdentificador);
        }
        unidades.add(u);
    }

  
    public void mostrarUnidades() {
        for (UnidadesOperativas u : unidades) {
            System.out.println(u.toString());
        }
    }

  
    public void moverUnidades() {
        for (UnidadesOperativas u : unidades) {
            if (u instanceof Movible) {
                Movible m = (Movible) u;
                int nuevoModulo = u.modulo + 1; 
                m.cambiarModulo(nuevoModulo);
            } else {
                System.out.println(u.nombreIdentificador + " no puede moverse (experimento fijo)");
            }
        }
    }

   
    public void realizarFuncionesBase() {
        for (UnidadesOperativas u : unidades) {
            u.reabastecerse();
            u.mantenerCondicionesAtmosfericas();
            u.replicarse();
        }
    }

   
    public List<UnidadesOperativas> filtrarPorTipoAtmosfera(TipoAtmosfera tipo) {
        List<UnidadesOperativas> resultado = new ArrayList<>();
        for (UnidadesOperativas u : unidades) {
            if (u.operaEn(tipo)) {
                resultado.add(u);
            }
        }
        return resultado;
    }
}
