package baseespacial;

public class Astronautas extends UnidadesOperativas implements Movible {
    private int maxEVA; // horas

    public Astronautas(String nombreIdentificador, int modulo, TipoAtmosfera tipoAtmosfera, int maxEVA) {
        super(nombreIdentificador, modulo, tipoAtmosfera);
        this.maxEVA = maxEVA;
    }

    @Override
    public void replicarse() {
        System.out.println(nombreIdentificador + ": entrenando nuevos astronautas...");
    }

    @Override
    public void cambiarModulo(int moduloNuevo) {
        this.modulo = moduloNuevo;
        System.out.println(nombreIdentificador + " se movió al módulo " + moduloNuevo);
    }

    @Override
    public void reabastecerse() {
        System.out.println(nombreIdentificador + ": reabastecimiento humano (kits y oxígeno)...");
    }

    @Override
    public String toString() {
        return super.toString() + " | maxEVA: " + maxEVA;
    }
}
