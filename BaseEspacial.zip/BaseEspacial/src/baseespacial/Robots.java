package baseespacial;

public class Robots extends UnidadesOperativas implements Movible {
    private int autonomiaOperativa; // horas

    public Robots(String nombreIdentificador, int modulo, TipoAtmosfera tipoAtmosfera, int autonomiaOperativa) {
        super(nombreIdentificador, modulo, tipoAtmosfera);
        this.autonomiaOperativa = autonomiaOperativa;
    }

    @Override
    public void replicarse() {
        System.out.println(nombreIdentificador + ": copiando robots...");
    }

    @Override
    public void cambiarModulo(int moduloNuevo) {
        this.modulo = moduloNuevo;
        System.out.println(nombreIdentificador + " (robot) se movió al módulo " + moduloNuevo);
    }

    @Override
    public void reabastecerse() {
        System.out.println(nombreIdentificador + ": recargando baterías...");
    }

    @Override
    public String toString() {
        return super.toString() + " | autonomiaOperativa: " + autonomiaOperativa;
    }
}
