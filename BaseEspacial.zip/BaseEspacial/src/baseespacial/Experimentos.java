package baseespacial;

public class Experimentos extends UnidadesOperativas {
    private int duracionIdeal; // días

    public Experimentos(String nombreIdentificador, int modulo, TipoAtmosfera tipoAtmosfera, int duracionIdeal) {
        super(nombreIdentificador, modulo, tipoAtmosfera);
        this.duracionIdeal = duracionIdeal;
    }

    @Override
    public void replicarse() {
        System.out.println(nombreIdentificador + ": clonando protocolos...");
    }

    @Override
    public void cambiarModulo(int moduloNuevo) {
        System.out.println(nombreIdentificador + " no puede moverse (experimento fijo).");
    }

    @Override
    public String toString() {
        return super.toString() + " | duracionIdeal: " + duracionIdeal;
    }
}
